$('.flip-card-inner').click(function(){
    console.log('12312312')
    $(this).toggleClass('flipped');
  });